
package sample.actuator.log4j2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class HelloWorldService {

	@Autowired
	private ServiceProperties configuration;

	public String getHelloMessage() {
		return "Hello " + this.configuration.getName();
	}

}
