package com.ibm.constructor;

import java.util.Date;

/**
 */
public interface WeatherService {
   Double getHistoricalHigh(Date date);
}
