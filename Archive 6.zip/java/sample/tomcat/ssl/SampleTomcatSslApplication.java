
package sample.tomcat.ssl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleTomcatSslApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SampleTomcatSslApplication.class, args);
	}

}
