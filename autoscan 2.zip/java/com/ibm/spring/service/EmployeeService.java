package com.ibm.spring.service;

import com.ibm.spring.model.Employee;

public interface EmployeeService {

	void registerEmployee(Employee employee);
}

