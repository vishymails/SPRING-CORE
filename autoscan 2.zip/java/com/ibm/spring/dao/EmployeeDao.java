package com.ibm.spring.dao;

import com.ibm.spring.model.Employee;

public interface EmployeeDao {

	void saveInDatabase(Employee employee);
}
